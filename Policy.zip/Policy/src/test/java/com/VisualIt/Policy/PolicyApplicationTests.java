package com.VisualIt.Policy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolicyApplicationTests {

	@Test
	void contextLoads() {
	}

}
