package com.VisualIt.Policy.Exceptions;

public class ExceptionConstants {

	public static final String  POLICY_ALL_READY_EXISTED = "this policy All Ready Existed";
	public static final String  POLICY_GET_Id_Not_Found ="this Getpolicy id is Not found";
	public static final String  POLICY_DELETE_ID_NOT_FOUND="this Deletpolicy id is Not found";
	public static final String  POLICY_UPDATE_ID_NOT_FOUND ="this Updatepolicy id is Not found";
	
	
	   
}
