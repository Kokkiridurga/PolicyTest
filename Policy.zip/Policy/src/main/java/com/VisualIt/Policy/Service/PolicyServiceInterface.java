package com.VisualIt.Policy.Service;

import com.VisualIt.Policy.Payload.PolicyDto;

/**
 * @author durga
 *
 */
public interface PolicyServiceInterface {

	public PolicyDto SavePolicy( PolicyDto policy);

	

}
